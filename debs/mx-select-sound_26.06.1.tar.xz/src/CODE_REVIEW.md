# Code Review - MX Select Sound

This document lists the code issues identified in the **MX Select Sound** project, categorized by type. Each issue is marked with a checkbox so progress can be tracked.

---

## 🚨 Critical & Functional Issues

1. - [-] **Destructive Configuration Write in `pushApply_clicked()`**
   - **File / Location**: [MainWindow::pushApply_clicked](file:///home/adrian/mx-select-sound/src/mainwindow.cpp#L114-L125)
   - **Description**: Writing to `~/.asoundrc` completely overwrites the existing file:
     ```cpp
     asoundrc.open(QFile::WriteOnly | QFile::Text)
     ```
     If the user has any other custom configurations in their `~/.asoundrc` file, they will be deleted.
   - **Recommendation**: Parse the existing `~/.asoundrc` if it exists, replace or add the specific lines `defaults.pcm.!card` and `defaults.ctl.!card`, and write the modified content back.

2. - [x] **GUI Freeze During Sound Test**
   - **File / Location**: [MainWindow::pushTest_clicked](file:///home/adrian/mx-select-sound/src/mainwindow.cpp#L147-L153)
   - **Description**: Calling `speaker-test` synchronously blocks the GUI thread:
     ```cpp
     const int exitCode = runCmd(QStringLiteral("speaker-test -c 2 -t wav -l 2")).exitCode;
     ```
     Because `runCmd()` calls `proc.waitForFinished(-1)`, the GUI of the application will freeze and become completely unresponsive while the sound test is playing (which takes several seconds).
   - **Recommendation**: Run the `QProcess` asynchronously by connecting to its `finished()` signal, and disable the test button while the process is active to avoid multiple overlapping processes.

3. - [x] **Missing `Testing` Directory in Repository**
   - **File / Location**: [CMakeLists.txt#L190-L194](file:///home/adrian/mx-select-sound/CMakeLists.txt#L190-L194)
   - **Description**: If `BUILD_TESTS` is enabled, CMake attempts to load the `Testing` subdirectory:
     ```cmake
     if(BUILD_TESTS)
         message(STATUS "Building with tests enabled")
         add_subdirectory(Testing)
     endif()
     ```
     However, the `Testing` directory is missing from the repository, meaning configuring CMake with `-DBUILD_TESTS=ON` (or via `./build.sh --tests`) will result in a fatal CMake configuration error.
   - **Recommendation**: Either create the `Testing` directory and its `CMakeLists.txt` or remove the `BUILD_TESTS` option if tests are no longer supported.

---

## 🛠️ Build System & Portability Issues

4. - [x] **Broken File Paths in `mx-select-sound.pro`**
   - **File / Location**: [mx-select-sound.pro](file:///home/adrian/mx-select-sound/mx-select-sound.pro)
   - **Description**: The `qmake` project file lists source, header, and form files under the project root (e.g., `main.cpp`) rather than the `src/` directory where they are actually located. Attempting to build using `qmake` will fail.
   - **Recommendation**: Prefix the source, header, and UI file paths with `src/`, for example:
     ```make
     SOURCES += \
         src/main.cpp \
         src/about.cpp \
         src/mainwindow.cpp
     ```

5. - [x] **Fragile `translations/get_translations` Script**
   - **File / Location**: [translations/get_translations](file:///home/adrian/mx-select-sound/translations/get_translations)
   - **Description**: The script executes `find .` to delete old `.ts` files, but it does not change directory to the script's location (`translations/`). If a user executes this script from the repository root, it will run `find .` inside the root and delete files incorrectly. Additionally, it uses `../src` which is only correct if the working directory is `translations/`.
   - **Recommendation**: Add a command at the beginning of the script to change the working directory:
     ```bash
     cd "$SCRIPT_DIR" || exit 1
     ```

6. - [x] **CMake Compiler Selection Antipattern**
   - **File / Location**: [CMakeLists.txt#L61-L68](file:///home/adrian/mx-select-sound/CMakeLists.txt#L61-L68)
   - **Description**: Setting `CMAKE_C_COMPILER` and `CMAKE_CXX_COMPILER` inside `CMakeLists.txt` *after* the `project()` call is too late, as CMake has already performed compiler detection. This can lead to compiler setting mismatches or broken builds.
   - **Recommendation**: Remove the compiler settings from the `CMakeLists.txt`. To compile with clang, users should set the `CC` and `CXX` environment variables (e.g., `CXX=clang++ cmake ...`) or pass the variables on the command line.

7. - [-] **Non-Portable Dependency on `dpkg-dev` in CMake**
   - **File / Location**: [CMakeLists.txt#L25-L36](file:///home/adrian/mx-select-sound/CMakeLists.txt#L25-L36)
   - **Description**: The project extracts its version using `dpkg-parsechangelog -SVersion`. This introduces a hard dependency on Debian packaging tools, making the project impossible to configure/build on non-Debian platforms (like Fedora, Arch, or openSUSE).
   - **Recommendation**: Implement a fallback mechanism or read the version from `debian/changelog` using CMake's built-in file processing/regex capabilities if `dpkg-parsechangelog` is not present.

---

## 🎨 User Interface & Experience (UI/UX) Issues

8. - [x] **Jarring GUI Flashing on About Dialog Click**
   - **File / Location**: [MainWindow::pushAbout_clicked](file:///home/adrian/mx-select-sound/src/mainwindow.cpp#L127-L139)
   - **Description**: The function calls `hide()` on the main window before opening the About dialog and `show()` after it closes:
     ```cpp
     hide();
     displayAboutMsgBox(...);
     show();
     ```
     This causes the main window to disappear and reappear, causing a jarring flashing effect. Since `displayAboutMsgBox` is a modal dialog, the main window is already blocked and does not need to be hidden.
   - **Recommendation**: Remove the calls to `hide()` and `show()`.

9. - [x] **Non-Standard Cancel Button Signal**
   - **File / Location**: [mainwindow.ui#L348-L363](file:///home/adrian/mx-select-sound/src/mainwindow.ui#L348-L363)
   - **Description**: The Cancel button (`pushCancel`) is connected using the `pressed()` signal:
     ```xml
     <signal>pressed()</signal>
     ```
     The standard signal for button interaction is `clicked()`. Using `pressed()` triggers the cancel action immediately on mouse press down rather than release, which prevents the user from canceling their click by dragging away, and can cause issues with keyboard focus navigation.
   - **Recommendation**: Change the signal in the `.ui` file to `clicked()`.

10. - [x] **Hardcoded Absolute Path for Icons**
    - **File / Location**: [mainwindow.ui#L293-L295](file:///home/adrian/mx-select-sound/src/mainwindow.ui#L293-L295)
    - **Description**: The `pushTest` button's icon path contains a hardcoded absolute file path with multiple directory traversals:
      ```xml
      <normaloff>../../../../../../../usr/share/pixmaps/mx/mx-select-sound.png</normaloff>
      ```
      This makes the UI file fragile and non-portable, breaking if built or packaged on a system with a different directory layout.
    - **Recommendation**: Use the Qt Resource System (`qrc`) or load the icon dynamically using the icon theme name (e.g., `QIcon::fromTheme(...)`).

11. - [x] **No Parent / Non-Standard Buttons in `displayAboutMsgBox`**
    - **File / Location**: [about.cpp#L93-L108](file:///home/adrian/mx-select-sound/src/about.cpp#L93-L108)
    - **Description**: `QMessageBox` is instantiated without a parent window or standard buttons:
      ```cpp
      QMessageBox msgBox(QMessageBox::NoIcon, title, message);
      ```
      This prevents proper modal centering over the main window. In addition, using custom buttons for Cancel/Close instead of standard ones (e.g., `QMessageBox::Cancel`) bypasses built-in OS layout guidelines and shortcut handling (such as pressing `Esc` to close).
    - **Recommendation**: Pass `qApp->activeWindow()` as the parent to the `QMessageBox` constructor, and use `QMessageBox::Cancel` or `QMessageBox::Close` for standard closing buttons.

---

## 📝 Code Quality & Maintainability Issues

12. - [x] **Unused Private Member Variable `MainWindow::output`**
    - **File / Location**: [MainWindow::output](file:///home/adrian/mx-select-sound/src/mainwindow.h#L62)
    - **Description**: The private member variable `QString output;` is declared in the header file but is never used anywhere in the implementation.
    - **Recommendation**: Remove the variable from the header file to clean up the code.

13. - [x] **`QApplication::applicationName` Accessed Before It Is Set**
    - **File / Location**: [main.cpp#L44](file:///home/adrian/mx-select-sound/src/main.cpp#L44)
    - **Description**: The application icon and translation paths depend on `QApplication::applicationName()`, but `QCoreApplication::setApplicationName(...)` is never called. This relies on the system's fallback to the binary filename, which can be inconsistent or change depending on the build configuration.
    - **Recommendation**: Explicitly set the application name early in `main()`:
      ```cpp
      QCoreApplication::setApplicationName(QStringLiteral("mx-select-sound"));
      ```

14. - [x] **Inefficient Shell Command Execution**
    - **File / Location**: [MainWindow::runCmd](file:///home/adrian/mx-select-sound/src/mainwindow.cpp#L59-L67)
    - **Description**: The application spawns shell processes using `bash -c` with commands like `cat /proc/asound/cards | sed ...` or `sed ... ~/.asoundrc`. Spawning subprocesses is slow, resource-heavy, and less secure.
    - **Recommendation**: Implement these reads using native C++ code with `QFile`, `QTextStream`, and `QRegularExpression` to process `/proc/asound/cards` and `~/.asoundrc`.

15. - [x] **Fragile Path to Changelog File**
    - **File / Location**: [about.cpp#L115-L121](file:///home/adrian/mx-select-sound/src/about.cpp#L115-L121)
    - **Description**: The path to `changelog.gz` is hardcoded as:
      ```cpp
      QStringLiteral("/usr/share/doc/") + QFileInfo(QCoreApplication::applicationFilePath()).fileName() + QStringLiteral("/changelog.gz")
      ```
      This assumes the application is installed in `/usr` (which is false during development or custom install prefixes) and does not handle `changelog.Debian.gz`, which is the standard filename on Debian-based systems when there's no upstream changelog.
    - **Recommendation**: Check if the file exists before spawning `zcat`, and fallback to standard filenames or search paths if the primary file is missing.

16. - [x] **No Local Translation Fallback in Development**
    - **File / Location**: [main.cpp#L55-L58](file:///home/adrian/mx-select-sound/src/main.cpp#L55-L58)
    - **Description**: The application loads its translations strictly from `/usr/share/mx-select-sound/locale`. When developing or testing locally, the translation files will not be found and the interface will display only the default fallback language.
    - **Recommendation**: Add a fallback lookup path in `main.cpp` for the local build directory or `translations/` directory when running in a development context.
