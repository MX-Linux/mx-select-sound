# **********************************************************************
# * Copyright (C) 2015-2026 MX Authors
# *
# * Authors: Adrian
# *          MX Linux <http://mxlinux.org>
# *
# * This file is part of mx-select-sound.
# *
# * mx-select-sound is free software: you can redistribute it and/or modify
# * it under the terms of the GNU General Public License as published by
# * the Free Software Foundation, either version 3 of the License, or
# * (at your option) any later version.
# *
# * mx-select-sound is distributed in the hope that it will be useful,
# * but WITHOUT ANY WARRANTY; without even the implied warranty of
# * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# * GNU General Public License for more details.
# *
# * You should have received a copy of the GNU General Public License
# * along with mx-select-sound.  If not, see <http://www.gnu.org/licenses/>.
# **********************************************************************/

QT       += core gui widgets
CONFIG   += warn_on strict_c++ c++20

QMAKE_CXXFLAGS += -Wpedantic -pedantic -Werror=return-type -Werror=switch
QMAKE_CXXFLAGS += -Werror=uninitialized -Werror=return-local-addr -Werror

# The following define makes your compiler warn you if you use any
# feature of Qt which has been marked as deprecated (the exact warnings
# depend on your compiler). Please consult the documentation of the
# deprecated API in order to know how to port your code away from it.
DEFINES += QT_DEPRECATED_WARNINGS

TARGET = mx-select-sound
TEMPLATE = app


SOURCES += \
    src/main.cpp \
    src/about.cpp \
    src/mainwindow.cpp \
    src/cardutils.cpp

HEADERS  += \
    src/about.h \
    src/mainwindow.h \
    src/cardutils.h

FORMS    += \
    src/mainwindow.ui

TRANSLATIONS += \
    translations/mx-select-sound_en.ts

RESOURCES += \
    images.qrc


