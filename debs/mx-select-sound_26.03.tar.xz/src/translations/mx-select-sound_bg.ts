<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="bg">
<context>
    <name>mxselectsound</name>
    <message>
        <location filename="mxselectsound.ui" line="14"/>
        <location filename="mxselectsound.cpp" line="46"/>
        <location filename="mxselectsound.cpp" line="82"/>
        <location filename="mxselectsound.cpp" line="140"/>
        <location filename="mxselectsound.cpp" line="152"/>
        <location filename="mxselectsound.cpp" line="186"/>
        <location filename="mxselectsound.cpp" line="195"/>
        <source>MX Select Sound</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="28"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Your current default sound card is:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="64"/>
        <source>Display help </source>
        <translation>Помощ за дисплея</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="67"/>
        <source>Help</source>
        <translation>Помощ</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="75"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="104"/>
        <source>About this application</source>
        <translation>Относно това приложение</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="107"/>
        <source>About...</source>
        <translation>Относно...</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="115"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="147"/>
        <source>Quit application</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="150"/>
        <source>Close</source>
        <translation>Затваряне</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="158"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="199"/>
        <source>Apply</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="222"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select another sound card if necessary:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="248"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If your computer has more than one sound card, you can use this application to select the one to be default. &lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="294"/>
        <source>Test current sound card</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="83"/>
        <source>No sound cards/devices were found.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="95"/>
        <location filename="mxselectsound.cpp" line="109"/>
        <source>none</source>
        <translation>няма</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="139"/>
        <source>About MX Select Sound</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="140"/>
        <source>Version: </source>
        <translation>Версия:</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="141"/>
        <source>Program for selecting the default sound card in MX Linux</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="143"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="144"/>
        <location filename="mxselectsound.cpp" line="152"/>
        <source>License</source>
        <translation>Лиценз</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="145"/>
        <source>Changelog</source>
        <translation>Промени</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="146"/>
        <source>Cancel</source>
        <translation>Отмяна</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="161"/>
        <source>&amp;Close</source>
        <translation>&amp;Затвори</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="196"/>
        <source>Could not play test sound.</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>