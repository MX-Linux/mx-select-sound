<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="el">
<context>
    <name>mxselectsound</name>
    <message>
        <location filename="mxselectsound.ui" line="14"/>
        <location filename="mxselectsound.cpp" line="46"/>
        <location filename="mxselectsound.cpp" line="82"/>
        <location filename="mxselectsound.cpp" line="140"/>
        <location filename="mxselectsound.cpp" line="152"/>
        <location filename="mxselectsound.cpp" line="186"/>
        <location filename="mxselectsound.cpp" line="195"/>
        <source>MX Select Sound</source>
        <translation>MX Επιλογή ήχου</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="28"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Your current default sound card is:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Η τρέχουσα επιλογή για τη βασική κάρτα ήχου σας είναι:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="64"/>
        <source>Display help </source>
        <translation>Εμφάνιση βοήθειας </translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="67"/>
        <source>Help</source>
        <translation>Βοήθεια</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="75"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="104"/>
        <source>About this application</source>
        <translation>Περί της εφαρμογής</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="107"/>
        <source>About...</source>
        <translation>Περί...</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="115"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="147"/>
        <source>Quit application</source>
        <translation>Κλείσιμο εφαρμογής</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="150"/>
        <source>Close</source>
        <translation>Κλείσιμο</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="158"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="199"/>
        <source>Apply</source>
        <translation>Εφαρμογή</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="222"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select another sound card if necessary:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Επιλέξτε άλλη κάρτα ήχου αν είναι απαραίτητο:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="248"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If your computer has more than one sound card, you can use this application to select the one to be default. &lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Εάν ο υπολογιστής σας διαθέτει περισσότερες από μία κάρτες ήχου, μπορείτε να χρησιμοποιήσετε αυτήν την εφαρμογή για να επιλέξετε τη βασική.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="294"/>
        <source>Test current sound card</source>
        <translation>Έλεγχος της τρέχουσας κάρτας ήχου</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="83"/>
        <source>No sound cards/devices were found.</source>
        <translation>Δε βρέθηκαν κάρτες ήχου/συσκευές.</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="95"/>
        <location filename="mxselectsound.cpp" line="109"/>
        <source>none</source>
        <translation>καμία</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="139"/>
        <source>About MX Select Sound</source>
        <translation>Περί του MX Επιλογή ήχου</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="140"/>
        <source>Version: </source>
        <translation>Έκδοση: </translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="141"/>
        <source>Program for selecting the default sound card in MX Linux</source>
        <translation>Πρόγραμμα για την επιλογή βασικής κάρτας ήχου στο MX Linux</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="143"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Πνευματικά δικαιώματα (c) MX Linux</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="144"/>
        <location filename="mxselectsound.cpp" line="152"/>
        <source>License</source>
        <translation>Άδεια</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="145"/>
        <source>Changelog</source>
        <translation>Αρχείο αλλαγών</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="146"/>
        <source>Cancel</source>
        <translation>Άκυρο</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="161"/>
        <source>&amp;Close</source>
        <translation>&amp;Κλείσιμο</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="196"/>
        <source>Could not play test sound.</source>
        <translation>Δεν αναπαράγεται ήχος δοκιμής.</translation>
    </message>
</context>
</TS>