<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ru">
<context>
    <name>mxselectsound</name>
    <message>
        <location filename="mxselectsound.ui" line="14"/>
        <location filename="mxselectsound.cpp" line="46"/>
        <location filename="mxselectsound.cpp" line="82"/>
        <location filename="mxselectsound.cpp" line="140"/>
        <location filename="mxselectsound.cpp" line="152"/>
        <location filename="mxselectsound.cpp" line="186"/>
        <location filename="mxselectsound.cpp" line="195"/>
        <source>MX Select Sound</source>
        <translation>MX Выбор звуковой карты</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="28"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Your current default sound card is:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ваша текущая звуковая карта по умолчанию:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="64"/>
        <source>Display help </source>
        <translation>Показать справку</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="67"/>
        <source>Help</source>
        <translation>Справка</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="75"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="104"/>
        <source>About this application</source>
        <translation>Об этом приложении</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="107"/>
        <source>About...</source>
        <translation>О программе...</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="115"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="147"/>
        <source>Quit application</source>
        <translation>Выйти из приложения</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="150"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="158"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="199"/>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="222"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select another sound card if necessary:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Выбор другой звуковой карты по необходимости:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="248"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If your computer has more than one sound card, you can use this application to select the one to be default. &lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Если Ваш компьютер имеет более одной звуковой карты, Вы можете использовать это приложение для выбора одной из них по умолчанию. &lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="mxselectsound.ui" line="294"/>
        <source>Test current sound card</source>
        <translation>Проверить текущую звуковую карту</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="83"/>
        <source>No sound cards/devices were found.</source>
        <translation>Не обнаружено звуковых карт/устройств.</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="95"/>
        <location filename="mxselectsound.cpp" line="109"/>
        <source>none</source>
        <translation>нет</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="139"/>
        <source>About MX Select Sound</source>
        <translation>О программе MX Выбор звуковой карты</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="140"/>
        <source>Version: </source>
        <translation>Версия:</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="141"/>
        <source>Program for selecting the default sound card in MX Linux</source>
        <translation>Программа для выбора звуковой карты по умолчанию в MX Linux</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="143"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Авторское право (c) MX Linux</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="144"/>
        <location filename="mxselectsound.cpp" line="152"/>
        <source>License</source>
        <translation>Лицензия</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="145"/>
        <source>Changelog</source>
        <translation>Список изменений</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="146"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="161"/>
        <source>&amp;Close</source>
        <translation>&amp;Закрыть</translation>
    </message>
    <message>
        <location filename="mxselectsound.cpp" line="196"/>
        <source>Could not play test sound.</source>
        <translation>Не удалось воспроизвести тестовый звук.</translation>
    </message>
</context>
</TS>